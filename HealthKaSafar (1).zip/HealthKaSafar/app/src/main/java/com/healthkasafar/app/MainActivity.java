package com.healthkasafar.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String HOME_URL = "https://healthkasafar.blogspot.com/";
    // Blogger can redirect to a country domain (e.g. healthkasafar.blogspot.pk)
    private static final String HOST_PREFIX = "healthkasafar.blogspot.";

    // Remembers the file name a page gives to <a download="..."> so saved files get the right name
    private static final String NAME_TRACKER_JS =
            "(function(){if(window.__hksPatched)return;window.__hksPatched=true;"
            + "var oc=HTMLAnchorElement.prototype.click;"
            + "HTMLAnchorElement.prototype.click=function(){try{if(this.hasAttribute('download'))"
            + "window.__hksName=this.getAttribute('download')||'';}catch(e){}return oc.apply(this,arguments);};"
            + "document.addEventListener('click',function(e){var a=e.target&&e.target.closest?"
            + "e.target.closest('a[download]'):null;if(a)window.__hksName=a.getAttribute('download')||'';},true);})();";

    private WebView web;
    private SwipeRefreshLayout swipe;
    private ProgressBar progress;
    private View offline;
    private View splash;
    private FrameLayout fullscreen;

    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    private boolean hadError = false;
    private boolean splashHidden = false;
    private String failedUrl = null;
    private long lastBackPress = 0;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        web = findViewById(R.id.webview);
        swipe = findViewById(R.id.swipe);
        progress = findViewById(R.id.progress);
        offline = findViewById(R.id.offline);
        splash = findViewById(R.id.splash);
        fullscreen = findViewById(R.id.fullscreen);

        swipe.setColorSchemeResources(R.color.brand_green);
        swipe.setProgressBackgroundColorSchemeResource(R.color.brand_card);
        swipe.setOnRefreshListener(() -> web.reload());
        swipe.setOnChildScrollUpCallback((parent, child) -> web.getScrollY() > 0);

        findViewById(R.id.btn_retry).setOnClickListener(v -> retry());

        setupWebView();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                onBack();
            }
        });

        web.loadUrl(HOME_URL);
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void setupWebView() {
        web.setBackgroundColor(Color.parseColor("#050D0A"));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        CookieManager.getInstance().setAcceptCookie(true);

        AndroidBridge bridge = new AndroidBridge();
        web.addJavascriptInterface(bridge, "AndroidBridge");
        web.addJavascriptInterface(bridge, "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                return handleUrl(request.getUrl());
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (url != null && !url.startsWith("data:")) {
                    hadError = false;
                }
                progress.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                swipe.setRefreshing(false);
                if (!hadError) hideSplash();
                view.evaluateJavascript(NAME_TRACKER_JS, null);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    failedUrl = request.getUrl().toString();
                    showOffline();
                }
            }

            @SuppressWarnings("deprecation")
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                    failedUrl = failingUrl;
                    showOffline();
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel(); // never proceed on invalid certificates
                failedUrl = view.getUrl();
                showOffline();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                if (newProgress >= 70 && !hadError) hideSplash();
                if (newProgress >= 100) progress.setVisibility(View.GONE);
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                fullscreen.addView(view, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                fullscreen.setVisibility(View.VISIBLE);
                setSystemBarsHidden(true);
            }

            @Override
            public void onHideCustomView() {
                hideCustomView();
            }
        });

        web.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimeType, long contentLength) {
                handleDownload(url, userAgent, contentDisposition, mimeType);
            }
        });
    }

    // ---------- Navigation helpers ----------

    private boolean isInternal(Uri uri) {
        String scheme = uri.getScheme();
        String host = uri.getHost();
        if (scheme == null || host == null) return false;
        if (!scheme.equals("http") && !scheme.equals("https")) return false;
        host = host.toLowerCase(Locale.ROOT);
        return host.startsWith(HOST_PREFIX)
                || host.equals("blogger.com")
                || host.endsWith(".blogger.com");
    }

    /** @return true if the app handled the URL itself (WebView should not load it). */
    private boolean handleUrl(Uri uri) {
        if (isInternal(uri)) return false;

        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        switch (scheme) {
            case "about":
            case "javascript":
            case "data":
            case "blob":
                return false;
            case "http":
            case "https":
            case "tel":
            case "mailto":
            case "sms":
            case "geo":
            case "whatsapp":
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException ignored) {
                    // no app can handle this link
                }
                return true;
            default:
                return true; // ignore unknown schemes
        }
    }

    private void onBack() {
        if (customView != null) {
            hideCustomView();
            return;
        }
        if (offline.getVisibility() == View.VISIBLE) {
            exitOnDoubleBack();
            return;
        }
        if (web.canGoBack()) {
            web.goBack();
        } else {
            exitOnDoubleBack();
        }
    }

    private void hideCustomView() {
        if (customView == null) return;
        fullscreen.removeView(customView);
        fullscreen.setVisibility(View.GONE);
        customView = null;
        if (customViewCallback != null) customViewCallback.onCustomViewHidden();
        customViewCallback = null;
        setSystemBarsHidden(false);
    }

    private void exitOnDoubleBack() {
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 2000) {
            finish();
        } else {
            lastBackPress = now;
            Toast.makeText(this, R.string.press_back_again, Toast.LENGTH_SHORT).show();
        }
    }

    // ---------- UI state ----------

    private void hideSplash() {
        if (splashHidden) return;
        splashHidden = true;
        splash.animate().alpha(0f).setDuration(300).withEndAction(() -> splash.setVisibility(View.GONE));
    }

    private void showOffline() {
        hadError = true;
        splashHidden = true;
        splash.animate().cancel();
        splash.setVisibility(View.GONE);
        progress.setVisibility(View.GONE);
        swipe.setRefreshing(false);
        swipe.setVisibility(View.INVISIBLE);
        offline.setVisibility(View.VISIBLE);
    }

    private void retry() {
        offline.setVisibility(View.GONE);
        swipe.setVisibility(View.VISIBLE);
        hadError = false;
        web.loadUrl(failedUrl != null && failedUrl.startsWith("http") ? failedUrl : HOME_URL);
    }

    private void setSystemBarsHidden(boolean hidden) {
        WindowInsetsControllerCompat c =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (hidden) {
            c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            c.hide(WindowInsetsCompat.Type.systemBars());
        } else {
            c.show(WindowInsetsCompat.Type.systemBars());
        }
    }

    // ---------- Saving files (blob: / data: / normal links) ----------

    private void handleDownload(String url, String userAgent, String contentDisposition, String mimeType) {
        if (url == null) return;
        if (url.startsWith("data:")) {
            final String u = url;
            new Thread(() -> saveDataUrlInternal(u, null)).start();
        } else if (url.startsWith("blob:")) {
            fetchBlob(url);
        } else {
            startDownload(url, userAgent, contentDisposition, mimeType);
        }
    }

    /** Reads a blob: URL inside the page and hands the bytes to the app. */
    private void fetchBlob(String url) {
        String js = "(function(){var n=window.__hksName||'';fetch(" + JSONObject.quote(url) + ")"
                + ".then(function(r){return r.blob();})"
                + ".then(function(b){var fr=new FileReader();"
                + "fr.onloadend=function(){AndroidBridge.saveDataUrl(fr.result,n);};"
                + "fr.readAsDataURL(b);})"
                + ".catch(function(e){AndroidBridge.saveFailed(String(e));});})();";
        web.evaluateJavascript(js, null);
    }

    private void saveDataUrlInternal(String dataUrl, String nameHint) {
        try {
            int comma = dataUrl == null ? -1 : dataUrl.indexOf(',');
            if (comma < 0 || !dataUrl.startsWith("data:")) throw new IOException("bad data url");
            String meta = dataUrl.substring(5, comma);
            String payload = dataUrl.substring(comma + 1);
            String mime = meta.split(";")[0];
            if (mime.isEmpty()) mime = "application/octet-stream";
            byte[] bytes = meta.contains(";base64")
                    ? Base64.decode(payload, Base64.DEFAULT)
                    : Uri.decode(payload).getBytes("UTF-8");
            saveBytes(bytes, mime, nameHint);
        } catch (Exception e) {
            toastUi("File save nahi ho saki");
        }
    }

    private void saveBytes(byte[] data, String mime, String nameHint) {
        String hint = nameHint == null ? "" : nameHint.trim().replaceAll("[\\/:*?\"<>|]", "_");
        int dot = hint.lastIndexOf('.');
        if ((mime == null || mime.equals("application/octet-stream")) && dot > 0) {
            String guess = MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(hint.substring(dot + 1).toLowerCase(Locale.ROOT));
            if (guess != null) mime = guess;
        }
        if (mime == null || mime.isEmpty()) mime = "application/octet-stream";

        String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
        if (ext == null) ext = "bin";
        String name = hint;
        if (name.isEmpty()) {
            name = "HealthKaSafar_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        }
        if (!name.contains(".")) name = name + "." + ext;

        boolean image = mime.startsWith("image/");
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH,
                        image ? Environment.DIRECTORY_PICTURES + "/HealthKaSafar" : Environment.DIRECTORY_DOWNLOADS);
                Uri collection = image
                        ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                Uri item = getContentResolver().insert(collection, v);
                if (item == null) throw new IOException("insert failed");
                try (OutputStream os = getContentResolver().openOutputStream(item)) {
                    if (os == null) throw new IOException("no stream");
                    os.write(data);
                }
            } else {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> ActivityCompat.requestPermissions(this,
                            new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1));
                    toastUi("Permission allow karein, phir dobara save dabayen");
                    return;
                }
                File dir = Environment.getExternalStoragePublicDirectory(
                        image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS);
                if (image) dir = new File(dir, "HealthKaSafar");
                //noinspection ResultOfMethodCallIgnored
                dir.mkdirs();
                File f = new File(dir, name);
                int n = 1;
                while (f.exists()) {
                    int d = name.lastIndexOf('.');
                    String base = d > 0 ? name.substring(0, d) : name;
                    String suffix = d > 0 ? name.substring(d) : "";
                    f = new File(dir, base + "_" + (n++) + suffix);
                }
                try (FileOutputStream fos = new FileOutputStream(f)) {
                    fos.write(data);
                }
                MediaScannerConnection.scanFile(this, new String[]{f.getAbsolutePath()}, new String[]{mime}, null);
            }
            toastUi(image
                    ? "Save ho gaya: Gallery > HealthKaSafar (" + name + ")"
                    : "Save ho gaya: Downloads folder mein (" + name + ")");
        } catch (Exception e) {
            toastUi("File save nahi ho saki");
        }
    }

    private void toastUi(final String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
    }

    // ---------- Downloads ----------

    private void startDownload(String url, String userAgent, String contentDisposition, String mimeType) {
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.setMimeType(mimeType);
            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null) r.addRequestHeader("cookie", cookies);
            r.addRequestHeader("User-Agent", userAgent);
            String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            Toast.makeText(this, R.string.download_started, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            // Fall back to the system browser if DownloadManager is not allowed
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (ActivityNotFoundException ignored) {
            }
        }
    }

    // ---------- JS bridge (kept for the website) ----------

    public class AndroidBridge {
        @JavascriptInterface
        public void toast(final String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void saveDataUrl(String dataUrl, String fileName) {
            saveDataUrlInternal(dataUrl, fileName);
        }

        @JavascriptInterface
        public void saveBase64(String base64, String mimeType, String fileName) {
            try {
                saveBytes(Base64.decode(base64, Base64.DEFAULT), mimeType, fileName);
            } catch (Exception e) {
                toastUi("File save nahi ho saki");
            }
        }

        @JavascriptInterface
        public void saveFailed(String reason) {
            toastUi("File save nahi ho saki");
        }
    }

    // ---------- Lifecycle ----------

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.stopLoading();
            ((ViewGroup) web.getParent()).removeView(web);
            web.destroy();
        }
        super.onDestroy();
    }
}
