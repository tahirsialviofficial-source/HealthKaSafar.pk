GITHUB PAR APK BANANE KE STEPS (Phone ya PC)

1. Is zip ko EXTRACT karein (GitHub zip ko khud nahi kholta).
2. github.com par naya repository banayen (Public ya Private).
3. "Add file" > "Upload files" > extracted "HealthKaSafar" folder ko drag/select karein
   > "Commit changes".
   (Agar phone par folder select nahi hota, to folder ke andar jaa kar saari files/folders select karein.)
4. "Add file" > "Create new file". Naam mein ye likhein (slash ke saath):
        .github/workflows/build.yml
   Phir "build.yml" file ka poora text copy karke paste karein > "Commit changes".
5. "Actions" tab kholein > "Build APK" > "Run workflow".
6. 3-5 minute baad run khol kar neeche "Artifacts" se HealthKaSafar-APK download karein.
   Zip extract karke andar app-debug.apk install karein (purana app pehle uninstall karein).
