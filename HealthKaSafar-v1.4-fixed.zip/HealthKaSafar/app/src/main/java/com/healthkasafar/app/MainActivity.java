package com.healthkasafar.app;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.webkit.WebView.HitTestResult;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;
import android.util.Base64;

public class MainActivity extends AppCompatActivity {
    private static final String HOME_URL = "https://healthkasafar.blogspot.com/";
    private static final String HOST_PREFIX = "healthkasafar.blogspot.";

    private WebView web;
    private SwipeRefreshLayout swipe;
    private ProgressBar progress;
    private View offline;
    private View splash;
    private FrameLayout fullscreen;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private boolean hadError = false;
    private boolean splashHidden = false;
    private String failedUrl = null;
    private long lastBackPress = 0;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        web = findViewById(R.id.webview);
        swipe = findViewById(R.id.swipe);
        progress = findViewById(R.id.progress);
        offline = findViewById(R.id.offline);
        splash = findViewById(R.id.splash);
        fullscreen = findViewById(R.id.fullscreen);

        swipe.setColorSchemeResources(R.color.brand_green);
        swipe.setProgressBackgroundColorSchemeResource(R.color.brand_card);
        swipe.setOnRefreshListener(() -> web.reload());
        swipe.setOnChildScrollUpCallback((parent, child) -> web.getScrollY() > 0);
        findViewById(R.id.btn_retry).setOnClickListener(v -> retry());
        setupWebView();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { onBack(); }
        });
        web.loadUrl(HOME_URL);
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void setupWebView() {
        web.setBackgroundColor(Color.parseColor("#050D0A"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);

        AndroidBridge bridge = new AndroidBridge();
        web.addJavascriptInterface(bridge, "AndroidBridge");
        web.addJavascriptInterface(bridge, "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                return handleUrl(request.getUrl());
            }
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (url != null && !url.startsWith("data:")) hadError = false;
                progress.setVisibility(View.VISIBLE);
            }
            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                swipe.setRefreshing(false);
                injectNativeHelpers();
                if (!hadError) hideSplash();
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) { failedUrl = request.getUrl().toString(); showOffline(); }
            }
            @SuppressWarnings("deprecation")
            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) { failedUrl = failingUrl; showOffline(); }
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel(); failedUrl = view.getUrl(); showOffline();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                if (newProgress >= 70 && !hadError) hideSplash();
                if (newProgress >= 100) progress.setVisibility(View.GONE);
            }
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view; customViewCallback = callback;
                fullscreen.addView(view, new FrameLayout.LayoutParams(-1, -1));
                fullscreen.setVisibility(View.VISIBLE); setSystemBarsHidden(true);
            }
            @Override public void onHideCustomView() { hideCustomView(); }
        });

        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) ->
                startDownload(url, userAgent, contentDisposition, mimeType));
    }

    private boolean isInternal(Uri uri) {
        String scheme = uri.getScheme(), host = uri.getHost();
        if (scheme == null || host == null || !(scheme.equals("http") || scheme.equals("https"))) return false;
        host = host.toLowerCase(Locale.ROOT);
        return host.startsWith(HOST_PREFIX) || host.equals("blogger.com") || host.endsWith(".blogger.com");
    }

    private boolean handleUrl(Uri uri) {
        if (isInternal(uri)) return false;
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        if (scheme.equals("about") || scheme.equals("javascript") || scheme.equals("data") || scheme.equals("blob")) return false;
        if (scheme.equals("http") || scheme.equals("https") || scheme.equals("tel") || scheme.equals("mailto") || scheme.equals("sms") || scheme.equals("geo") || scheme.equals("whatsapp")) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (ActivityNotFoundException ignored) {}
            return true;
        }
        return true;
    }

    private void onBack() {
        if (customView != null) { hideCustomView(); return; }
        if (offline.getVisibility() == View.VISIBLE) { exitOnDoubleBack(); return; }
        if (web.canGoBack()) web.goBack(); else exitOnDoubleBack();
    }
    private void hideCustomView() {
        if (customView == null) return;
        fullscreen.removeView(customView); fullscreen.setVisibility(View.GONE); customView = null;
        if (customViewCallback != null) customViewCallback.onCustomViewHidden();
        customViewCallback = null; setSystemBarsHidden(false);
    }
    private void exitOnDoubleBack() {
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 2000) finish();
        else { lastBackPress = now; Toast.makeText(this, R.string.press_back_again, Toast.LENGTH_SHORT).show(); }
    }
    private void hideSplash() {
        if (splashHidden) return;
        splashHidden = true;
        splash.animate().alpha(0f).setDuration(220).withEndAction(() -> splash.setVisibility(View.GONE));
    }
    private void showOffline() {
        hadError = true; splashHidden = true; splash.animate().cancel(); splash.setVisibility(View.GONE);
        progress.setVisibility(View.GONE); swipe.setRefreshing(false); swipe.setVisibility(View.INVISIBLE); offline.setVisibility(View.VISIBLE);
    }
    private void retry() {
        offline.setVisibility(View.GONE); swipe.setVisibility(View.VISIBLE); hadError = false;
        web.loadUrl(failedUrl != null && failedUrl.startsWith("http") ? failedUrl : HOME_URL);
    }
    private void setSystemBarsHidden(boolean hidden) {
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (hidden) { c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE); c.hide(WindowInsetsCompat.Type.systemBars()); }
        else c.show(WindowInsetsCompat.Type.systemBars());
    }

    private void startDownload(String url, String userAgent, String contentDisposition, String mimeType) {
        if (url == null) return;
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            // The page-side bridge handles generated files. This route is intentionally not sent to DownloadManager.
            return;
        }
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mimeType != null && !mimeType.isEmpty()) r.setMimeType(mimeType);
            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null) r.addRequestHeader("Cookie", cookies);
            if (userAgent != null) r.addRequestHeader("User-Agent", userAgent);
            String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
            r.setTitle(name); r.setDescription(getString(R.string.app_name));
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            } else {
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            }
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            Toast.makeText(this, R.string.download_started, Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "Download failed. Please try again.", Toast.LENGTH_SHORT).show(); }
    }

    private void injectNativeHelpers() {
        String js = "javascript:(function(){try{" +
                "if(window.__hksNativeV2)return;window.__hksNativeV2=true;" +
                // Native print hook.
                "var nativePrint=function(){try{if(window.AndroidBridge&&AndroidBridge.printPage){AndroidBridge.printPage();return true;}}catch(e){}return false;};" +
                "window.print=nativePrint;" +
                // Blob registry: catches FileSaver.js and other generated downloads, including programmatic a.click().
                "var oldCreate=URL.createObjectURL;var blobMap={};" +
                "URL.createObjectURL=function(b){var u=oldCreate.call(URL,b);try{if(b)blobMap[u]=b;}catch(e){}return u;};" +
                "function sendBlob(b,n){try{if(!b)return false;var fr=new FileReader();fr.onloadend=function(){try{var x=fr.result||'';var p=x.indexOf(',');AndroidBridge.saveBase64Image(p>=0?x.substring(p+1):x,b.type||'image/jpeg',n||'HealthKaSafar.jpg');}catch(e){}};fr.readAsDataURL(b);return true;}catch(e){return false;}}" +
                "function saveHref(h,n){if(!h)return false;if(h.indexOf('blob:')===0&&blobMap[h])return sendBlob(blobMap[h],n);if(h.indexOf('data:image/')===0){var p=h.indexOf(',');if(p>=0){AndroidBridge.saveBase64Image(h.substring(p+1),h.substring(5,h.indexOf(';')),n||'HealthKaSafar.jpg');return true;}}return false;}" +
                "var oldClick=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){var h=this.href||this.getAttribute('href')||'';if(saveHref(h,this.download||'HealthKaSafar.jpg'))return;return oldClick.apply(this,arguments);};" +
                // User click capture for libraries that do not use prototype.click.
                "document.addEventListener('click',function(e){try{var a=e.target.closest&&e.target.closest('a');if(a&&saveHref(a.href||a.getAttribute('href'),a.download||'HealthKaSafar.jpg')){e.preventDefault();e.stopImmediatePropagation();return false;}var el=e.target.closest&&e.target.closest('[id*=print],[class*=print],[aria-label*=Print],[title*=Print]');if(el){var t=(el.innerText||el.getAttribute('aria-label')||el.getAttribute('title')||'').toLowerCase();if(t.indexOf('print')>=0){e.preventDefault();e.stopImmediatePropagation();nativePrint();return false;}}}catch(x){}},true);" +
                // Common print buttons whose text is only "Print".
                "document.addEventListener('click',function(e){try{var el=e.target.closest&&e.target.closest('button,input,[role=button]');if(!el)return;var t=((el.innerText||el.value||el.getAttribute('aria-label')||'')+'').trim().toLowerCase();if(t==='print'||t==='print report'||t==='print result'){e.preventDefault();nativePrint();}}catch(x){}},true);" +
                "}catch(e){}})();";
        web.evaluateJavascript(js, null);
    }

    private void printWebPage() {
        try {
            web.evaluateJavascript("javascript:(function(){try{document.body.classList.add('hks-native-print');}catch(e){}})();", null);
            PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            String jobName = getString(R.string.app_name) + " - Print";
            android.print.PrintDocumentAdapter adapter = web.createPrintDocumentAdapter(jobName);
            pm.print(jobName, adapter, new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("hks", "HealthKaSafar", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build());
        } catch (Exception e) {
            Toast.makeText(this, "Print is not available on this device.", Toast.LENGTH_LONG).show();
        }
    }

    private void saveBase64Image(String base64, String mimeType, String requestedName) {
        if (base64 == null || base64.isEmpty()) { Toast.makeText(this, "Image could not be saved.", Toast.LENGTH_LONG).show(); return; }
        try {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            boolean png = mimeType != null && mimeType.toLowerCase(Locale.ROOT).contains("png");
            String ext = png ? ".png" : ".jpg";
            String name = requestedName == null || requestedName.trim().isEmpty() ? "HealthKaSafar" + ext : requestedName.trim();
            name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
            if (!name.toLowerCase(Locale.ROOT).endsWith(".jpg") && !name.toLowerCase(Locale.ROOT).endsWith(".jpeg") && !name.toLowerCase(Locale.ROOT).endsWith(".png")) name += ext;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                values.put(MediaStore.Images.Media.MIME_TYPE, png ? "image/png" : "image/jpeg");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/HealthKaSafar");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
                Uri out = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (out == null) throw new IOException("MediaStore insert failed");
                try (OutputStream os = getContentResolver().openOutputStream(out)) { if (os == null) throw new IOException("Output stream unavailable"); os.write(bytes); }
                ContentValues done = new ContentValues(); done.put(MediaStore.Images.Media.IS_PENDING, 0); getContentResolver().update(out, done, null, null);
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "HealthKaSafar");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create folder");
                File out = new File(dir, name); try (FileOutputStream os = new FileOutputStream(out)) { os.write(bytes); }
                sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(out)));
            }
            Toast.makeText(this, "Image saved to Pictures/HealthKaSafar", Toast.LENGTH_LONG).show();
        } catch (Exception e) { Toast.makeText(this, "Image could not be saved: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    public class AndroidBridge {
        @JavascriptInterface public void toast(final String message) { runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show()); }
        @JavascriptInterface public void printPage() { runOnUiThread(MainActivity.this::printWebPage); }
        @JavascriptInterface public void saveBase64Image(final String base64, final String mimeType, final String fileName) { runOnUiThread(() -> saveBase64Image(base64, mimeType, fileName)); }
    }

    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onPause() { if (web != null) web.onPause(); super.onPause(); }
    @Override protected void onDestroy() {
        if (web != null) { web.stopLoading(); ViewGroup p=(ViewGroup)web.getParent(); if(p!=null)p.removeView(web); web.destroy(); }
        super.onDestroy();
    }
}
