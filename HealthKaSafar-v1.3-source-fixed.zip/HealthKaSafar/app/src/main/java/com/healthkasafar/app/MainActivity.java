package com.healthkasafar.app;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.util.Locale;
import java.io.OutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private static final String HOME_URL = "https://healthkasafar.blogspot.com/";
    // Blogger can redirect to a country domain (e.g. healthkasafar.blogspot.pk)
    private static final String HOST_PREFIX = "healthkasafar.blogspot.";

    private WebView web;
    private SwipeRefreshLayout swipe;
    private ProgressBar progress;
    private View offline;
    private View splash;
    private FrameLayout fullscreen;

    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    private boolean hadError = false;
    private boolean splashHidden = false;
    private String failedUrl = null;
    private long lastBackPress = 0;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        web = findViewById(R.id.webview);
        swipe = findViewById(R.id.swipe);
        progress = findViewById(R.id.progress);
        offline = findViewById(R.id.offline);
        splash = findViewById(R.id.splash);
        fullscreen = findViewById(R.id.fullscreen);

        swipe.setColorSchemeResources(R.color.brand_green);
        swipe.setProgressBackgroundColorSchemeResource(R.color.brand_card);
        swipe.setOnRefreshListener(() -> web.reload());
        swipe.setOnChildScrollUpCallback((parent, child) -> web.getScrollY() > 0);

        findViewById(R.id.btn_retry).setOnClickListener(v -> retry());

        setupWebView();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                onBack();
            }
        });

        web.loadUrl(HOME_URL);
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void setupWebView() {
        web.setBackgroundColor(Color.parseColor("#050D0A"));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(true);


        CookieManager.getInstance().setAcceptCookie(true);

        AndroidBridge bridge = new AndroidBridge();
        web.addJavascriptInterface(bridge, "AndroidBridge");
        web.addJavascriptInterface(bridge, "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                return handleUrl(request.getUrl());
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (url != null && !url.startsWith("data:")) {
                    hadError = false;
                }
                progress.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                swipe.setRefreshing(false);
                injectNativeHelpers();
                if (!hadError) hideSplash();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    failedUrl = request.getUrl().toString();
                    showOffline();
                }
            }

            @SuppressWarnings("deprecation")
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                    failedUrl = failingUrl;
                    showOffline();
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel(); // never proceed on invalid certificates
                failedUrl = view.getUrl();
                showOffline();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                if (newProgress >= 70 && !hadError) hideSplash();
                if (newProgress >= 100) progress.setVisibility(View.GONE);
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                fullscreen.addView(view, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                fullscreen.setVisibility(View.VISIBLE);
                setSystemBarsHidden(true);
            }

            @Override
            public void onHideCustomView() {
                hideCustomView();
            }
        });

        web.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimeType, long contentLength) {
                startDownload(url, userAgent, contentDisposition, mimeType);
            }
        });
    }

    // ---------- Navigation helpers ----------

    private boolean isInternal(Uri uri) {
        String scheme = uri.getScheme();
        String host = uri.getHost();
        if (scheme == null || host == null) return false;
        if (!scheme.equals("http") && !scheme.equals("https")) return false;
        host = host.toLowerCase(Locale.ROOT);
        return host.startsWith(HOST_PREFIX)
                || host.equals("blogger.com")
                || host.endsWith(".blogger.com");
    }

    /** @return true if the app handled the URL itself (WebView should not load it). */
    private boolean handleUrl(Uri uri) {
        if (isInternal(uri)) return false;

        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        switch (scheme) {
            case "about":
            case "javascript":
            case "data":
            case "blob":
                return false;
            case "http":
            case "https":
            case "tel":
            case "mailto":
            case "sms":
            case "geo":
            case "whatsapp":
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException ignored) {
                    // no app can handle this link
                }
                return true;
            default:
                return true; // ignore unknown schemes
        }
    }

    private void onBack() {
        if (customView != null) {
            hideCustomView();
            return;
        }
        if (offline.getVisibility() == View.VISIBLE) {
            exitOnDoubleBack();
            return;
        }
        if (web.canGoBack()) {
            web.goBack();
        } else {
            exitOnDoubleBack();
        }
    }

    private void hideCustomView() {
        if (customView == null) return;
        fullscreen.removeView(customView);
        fullscreen.setVisibility(View.GONE);
        customView = null;
        if (customViewCallback != null) customViewCallback.onCustomViewHidden();
        customViewCallback = null;
        setSystemBarsHidden(false);
    }

    private void exitOnDoubleBack() {
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 2000) {
            finish();
        } else {
            lastBackPress = now;
            Toast.makeText(this, R.string.press_back_again, Toast.LENGTH_SHORT).show();
        }
    }

    // ---------- UI state ----------

    private void hideSplash() {
        if (splashHidden) return;
        splashHidden = true;
        splash.animate().alpha(0f).setDuration(300).withEndAction(() -> splash.setVisibility(View.GONE));
    }

    private void showOffline() {
        hadError = true;
        splashHidden = true;
        splash.animate().cancel();
        splash.setVisibility(View.GONE);
        progress.setVisibility(View.GONE);
        swipe.setRefreshing(false);
        swipe.setVisibility(View.INVISIBLE);
        offline.setVisibility(View.VISIBLE);
    }

    private void retry() {
        offline.setVisibility(View.GONE);
        swipe.setVisibility(View.VISIBLE);
        hadError = false;
        web.loadUrl(failedUrl != null && failedUrl.startsWith("http") ? failedUrl : HOME_URL);
    }

    private void setSystemBarsHidden(boolean hidden) {
        WindowInsetsControllerCompat c =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (hidden) {
            c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            c.hide(WindowInsetsCompat.Type.systemBars());
        } else {
            c.show(WindowInsetsCompat.Type.systemBars());
        }
    }

    // ---------- Downloads ----------

    private void startDownload(String url, String userAgent, String contentDisposition, String mimeType) {
        if (url == null || url.startsWith("blob:") || url.startsWith("data:")) {
            Toast.makeText(this, "Image download is being prepared…", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mimeType != null && !mimeType.isEmpty()) r.setMimeType(mimeType);
            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null) r.addRequestHeader("cookie", cookies);
            if (userAgent != null) r.addRequestHeader("User-Agent", userAgent);
            String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
            r.setTitle(name);
            r.setDescription(getString(R.string.app_name));
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            Toast.makeText(this, R.string.download_started, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Download failed. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    private void injectNativeHelpers() {
        String js = "javascript:(function(){" +
                "if(window.__hksNativeReady)return;window.__hksNativeReady=true;" +
                "window.print=function(){if(window.AndroidBridge&&AndroidBridge.printPage){AndroidBridge.printPage();}};" +
                "document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a');" +
                "if(a&&a.href&&a.href.indexOf('blob:')===0){e.preventDefault();" +
                "fetch(a.href).then(function(r){return r.blob()}).then(function(b){var fr=new FileReader();" +
                "fr.onloadend=function(){var x=fr.result||'';AndroidBridge.saveBase64Image(x.split(',')[1]||'',b.type||'image/jpeg',''+(a.download||'HealthKaSafar.jpg'));};fr.readAsDataURL(b);});}});" +
                "})();";
        web.evaluateJavascript(js, null);
    }

    private void printWebPage() {
        try {
            PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            String jobName = getString(R.string.app_name) + " - Print";
            android.print.PrintDocumentAdapter adapter = web.createPrintDocumentAdapter(jobName);
            pm.print(jobName, adapter, new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build());
        } catch (Exception e) {
            Toast.makeText(this, "Print is not available on this device.", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveBase64Image(String base64, String mimeType, String requestedName) {
        if (base64 == null || base64.isEmpty()) {
            Toast.makeText(this, "Image could not be saved.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            String ext = (mimeType != null && mimeType.toLowerCase(Locale.ROOT).contains("png")) ? ".png" : ".jpg";
            String name = requestedName == null || requestedName.trim().isEmpty() ? "HealthKaSafar" + ext : requestedName;
            if (!name.toLowerCase(Locale.ROOT).endsWith(ext)) name = name.replaceAll("\\.(jpg|jpeg|png)$", "") + ext;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                values.put(MediaStore.Images.Media.MIME_TYPE, mimeType != null ? mimeType : "image/jpeg");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/HealthKaSafar");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
                Uri out = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (out == null) throw new IOException("MediaStore insert failed");
                try (OutputStream os = getContentResolver().openOutputStream(out)) {
                    if (os == null) throw new IOException("Output stream unavailable");
                    os.write(bytes);
                }
                values.clear();
                values.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(out, values, null, null);
            } else {
                java.io.File dir = new java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "HealthKaSafar");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create folder");
                java.io.File out = new java.io.File(dir, name);
                try (java.io.FileOutputStream os = new java.io.FileOutputStream(out)) { os.write(bytes); }
                sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(out)));
            }
            Toast.makeText(this, "Image saved to Pictures/HealthKaSafar", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Image could not be saved.", Toast.LENGTH_LONG).show();
        }
    }

    // ---------- JS bridge (kept for the website) ----------

    public class AndroidBridge {
        @JavascriptInterface
        public void toast(final String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(MainActivity.this::printWebPage);
        }

        @JavascriptInterface
        public void saveBase64Image(final String base64, final String mimeType, final String fileName) {
            runOnUiThread(() -> saveBase64Image(base64, mimeType, fileName));
        }
    }

    // ---------- Lifecycle ----------

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.stopLoading();
            ((ViewGroup) web.getParent()).removeView(web);
            web.destroy();
        }
        super.onDestroy();
    }
}
